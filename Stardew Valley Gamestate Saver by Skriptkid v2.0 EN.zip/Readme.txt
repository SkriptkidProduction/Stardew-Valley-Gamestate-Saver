TYPE: Simple Batch with temporray VBS script
USAGE: Backup the savestate of Stardew Valley

To use the script, 7zip must be installed in the default directory. https://www.7-zip.de/

To keep the Script always on top is a program like xtrabuttons is necessary. http://www.xtrabuttons.com/
The Script could may not be always on top with xtrabuttons if Stardew Valley is in full screen mode


Subject to changes and errors

The script is welcome to be adapted, improved and distributed


Contact: user@skriptkid.de
Made by Skriptkid